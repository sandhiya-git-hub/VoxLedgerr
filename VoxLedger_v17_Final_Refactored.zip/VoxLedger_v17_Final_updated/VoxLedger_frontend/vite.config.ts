import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { API_PREFIXES } from "./shared/api-routes";

const BACKEND = process.env.VOXLEDGER_BACKEND_URL || "http://localhost:8000";

const proxyEntries = Object.fromEntries(
  API_PREFIXES.map((prefix) => [
    prefix,
    {
      target: BACKEND,
      changeOrigin: true,
    },
  ])
);

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./client"),
      "@shared": path.resolve(__dirname, "./shared"),
    },
  },
  root: ".",
  build: {
    outDir: "dist/public",
    emptyOutDir: true,
  },
  server: {
    port: 5173,
    proxy: proxyEntries,
  },
});
