/**
 * Shared API contracts and route definitions.
 */
export * from "./api-routes";

export interface PingResponse {
  message: string;
  timestamp: string;
}
