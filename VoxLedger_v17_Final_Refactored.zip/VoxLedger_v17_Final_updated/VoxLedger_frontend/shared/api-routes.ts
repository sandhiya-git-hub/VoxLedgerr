/**
 * Shared API route prefixes routed to the FastAPI backend.
 * Single source of truth shared between Vite dev proxy and Express production server.
 */
export const API_PREFIXES = [
  "/health",
  "/check-user",
  "/register",
  "/set-wake-phrase",
  "/extract-name-from-voice",
  "/verify-voice",
  "/logout",
  "/login",
  "/user",
  "/transactions",
  "/budget",
  "/notifications",
  "/voice",
] as const;

export type ApiPrefix = typeof API_PREFIXES[number];

export function isApiPath(url: string): boolean {
  const path = url.split("?")[0];
  return API_PREFIXES.some((prefix) => path === prefix || path.startsWith(prefix + "/"));
}
