@echo off
title VoxLedger Frontend v12.0
cd /d "%~dp0"
echo ===================================================
echo   VoxLedger Frontend v12.0 - Starting...
echo ===================================================
echo.

if not exist node_modules (
    echo Installing npm dependencies...
    npm install
)

echo   Frontend URL: http://localhost:5173
echo.
echo ===================================================
npm run dev
