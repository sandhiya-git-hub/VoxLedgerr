#!/bin/bash
# VoxLedger Frontend Startup Script

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "═══════════════════════════════════════════════════"
echo "  VoxLedger Frontend v12.0 — Starting..."
echo "═══════════════════════════════════════════════════"

# Check Node
if ! command -v node &>/dev/null; then
    echo "ERROR: Node.js not found. Please install Node 18+"
    exit 1
fi

# Install dependencies if missing
if [ ! -d "node_modules" ]; then
    echo "Installing npm dependencies..."
    npm install
fi

echo ""
echo "  Frontend URL: http://localhost:5173"
echo "  Backend must be running on: http://localhost:8000"
echo ""
echo "═══════════════════════════════════════════════════"

npm run dev
