import express from "express";
import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { isApiPath } from "../shared/api-routes";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3001);

// ── Backend proxy configuration ────────────────────────────────────────────
// Uses shared route list so proxy coverage stays 100% in sync with Vite dev proxy.
// Pipes raw byte streams to preserve multipart audio uploads and streamed TTS.
const BACKEND_HOST = process.env.VOXLEDGER_BACKEND_HOST || "localhost";
const BACKEND_PORT = Number(process.env.VOXLEDGER_BACKEND_PORT || 8000);

// Mounted BEFORE express.json()/static so the raw request stream is still
// available to pipe through untouched (critical for multipart audio bodies).
app.use((req, res, next) => {
  if (!req.url || !isApiPath(req.url)) return next();

  const proxyReq = http.request(
    {
      host: BACKEND_HOST,
      port: BACKEND_PORT,
      path: req.url,
      method: req.method,
      headers: { ...req.headers, host: `${BACKEND_HOST}:${BACKEND_PORT}` },
    },
    (proxyRes) => {
      res.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
      proxyRes.pipe(res);
    },
  );

  proxyReq.on("error", (err) => {
    console.error("[proxy] backend request failed:", err.message);
    if (!res.headersSent) {
      res.writeHead(502, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ detail: "Backend unreachable" }));
    }
  });

  req.pipe(proxyReq);
});

app.use(express.json());

// Health check for the Node server itself (distinct from backend /health)
app.get("/api/ping", (_req, res) => {
  res.json({ message: "pong", timestamp: new Date().toISOString() });
});

// Serve static files in production
// When compiled into dist/server/index.js, publicPath is dist/public
const publicPath = path.resolve(__dirname, "../public");
const indexHtmlPath = path.join(publicPath, "index.html");

if (process.env.NODE_ENV === "production" || fs.existsSync(indexHtmlPath)) {
  app.use(express.static(publicPath));
  app.get("*", (_req, res) => {
    res.sendFile(indexHtmlPath);
  });
}

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Proxying API routes to backend at http://${BACKEND_HOST}:${BACKEND_PORT}`);
});

export default app;
