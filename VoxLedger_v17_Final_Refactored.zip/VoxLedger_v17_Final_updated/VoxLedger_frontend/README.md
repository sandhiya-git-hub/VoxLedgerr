# VoxLedger Frontend

A modern, responsive, voice-first single-page application built with React 18, TypeScript, Tailwind CSS, Radix UI primitives, Framer Motion, and TanStack Query.

---

## 1. Structure & Key Responsibilities

```
VoxLedger_frontend/
├── client/
│   ├── main.tsx           # Application mount point
│   ├── App.tsx            # Routes, providers, auto-lock timeout manager
│   ├── assets/            # Static image assets and icons
│   ├── styles/            # Stylesheets
│   │   └── global.css     # Tailwind directives and theme variables
│   ├── components/        # Reusable React components
│   │   ├── Layout.tsx     # Persistent layout holding the ambient audio engine
│   │   ├── SplashScreen.tsx# Initialization screen with onboarding router
│   │   └── ui/            # Active Radix UI primitives (Button, Card, Dialog, etc.)
│   ├── context/           # React Context API
│   │   └── AppContext.tsx # Central store for user, auth, transactions, budget
│   ├── hooks/             # Custom hooks
│   │   └── use-toast.ts   # Toast dispatch hook
│   ├── lib/               # Utilities & Client SDK
│   │   ├── api.ts         # Type-safe API client attaching X-Session-Token
│   │   └── utils.ts       # Class merging helper (clsx + tailwind-merge)
│   └── pages/             # Application views
│       ├── Registration.tsx    # Step 1: Voice registration & name enrollment
│       ├── WakePhraseSetup.tsx # Step 2: Wake phrase configuration
│       ├── Locked.tsx          # Step 3: Biometric lock screen
│       ├── Greeting.tsx        # Step 4: Spoken greeting & overview
│       ├── Index.tsx           # Dashboard with summary & balance cards
│       ├── Transactions.tsx    # Interactive ledger (add, delete, filter)
│       ├── Budget.tsx          # Monthly and category budget allocation
│       ├── Notifications.tsx   # Proactive budget & system alert feed
│       ├── Alerts.tsx          # Categorized severity breakdown
│       ├── Conversation.tsx    # Spoken assistant chat log
│       └── Profile.tsx         # User profile and voice sample management
├── server/
│   └── index.ts           # Production Express server & reverse proxy
├── shared/
│   ├── api-routes.ts      # Shared list of API routes for proxies
│   └── api.ts             # Shared type definitions
├── index.html             # HTML entry template
├── package.json           # Dependencies and build scripts
├── tsconfig.json          # TypeScript compiler configuration
└── vite.config.ts         # Vite build and development proxy configuration
```

---

## 2. Voice Engine & Lifecycle

1. **Persistent Engine in `<Layout />`**:
   The microphone stream, audio context, and VAD calibration reside in `<Layout />`. Navigating between protected pages does NOT tear down or remount audio hardware.
2. **Instant Interruption**:
   Saying `"stop"` or clicking the microphone FAB triggers a `vox:force-stop` custom event, immediately terminating active HTMLAudioElement playback.
3. **Session Auto-Lock**:
   After 60 seconds of inactivity on protected routes, the session is cleared, audio streams are stopped, and the interface returns to the `/locked` screen.

---

## 3. Development & Production Scripts

```bash
# Install dependencies cleanly
npm ci

# Start Vite dev server on http://localhost:5173
npm run dev

# Run TypeScript typechecker
npm run typecheck

# Run Vitest unit tests
npm run test

# Compile production bundle (dist/public & dist/server/index.js)
npm run build

# Start production Express server on http://localhost:3001
npm start
```
