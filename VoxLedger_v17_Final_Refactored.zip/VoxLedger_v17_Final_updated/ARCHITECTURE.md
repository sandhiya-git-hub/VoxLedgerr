# VoxLedger System Architecture

This document provides a comprehensive technical overview of the **VoxLedger** system architecture, component boundaries, voice lifecycle, state management, security model, and production deployment design.

---

## 1. High-Level System Architecture

VoxLedger follows a decoupled, voice-first client-server architecture:

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CLIENT LAYER (Browser)                         │
│  React 18 + TypeScript + Tailwind CSS + Framer Motion + Web Audio API │
│  - Persistent Layout with Ambient Voice Engine                        │
│  - Audio Recording (MediaRecorder + AudioContext)                     │
│  - Audio Playback & Real-Time Interruption (HTMLAudioElement)         │
│  - Token-Based Session Management (sessionStorage + Memory)           │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │ HTTP / REST / Raw Audio Streams
                                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   FRONTEND GATEWAY / PROXY LAYER                      │
│                                                                        │
│  DEVELOPMENT MODE:                       PRODUCTION MODE:              │
│  Vite Dev Server (Port 5173)             Express Server (Port 3001)   │
│  - Hot Module Replacement (HMR)          - Bundled with esbuild       │
│  - Proxy via shared/api-routes           - Reverse Proxy (raw stream) │
│                                          - Serves dist/public assets  │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │ Forwarded Raw Byte Streams
                                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        FASTAPI BACKEND LAYER                           │
│                     Python 3.10+ (Port 8000)                          │
│                                                                        │
│  ┌───────────────────────┐  ┌──────────────────────────────────────┐  │
│  │     Routers & API     │  │           Core Services              │  │
│  │ - auth_routes         │  │ - voice_auth_service (MFCC + VAD)    │  │
│  │ - transaction_routes  │  │ - whisper_service (OpenAI Whisper)   │  │
│  │ - budget_routes       │  │ - tts_service (gTTS + ffmpeg tempo)  │  │
│  │ - notification_routes │  │ - finance_service (Ledger Engine)    │  │
│  │ - voice_routes        │  │ - session_service (Secure Tokens)    │  │
│  └───────────────────────┘  └──────────────────────────────────────┘  │
│  ┌───────────────────────┐  ┌──────────────────────────────────────┐  │
│  │  Session Auth Gate    │  │        Intent & Parsing Engine       │  │
│  │  X-Session-Token Auth │  │  - Keyword Parser (Deterministic)    │  │
│  │  Prevents Bypassing   │  │  - Multi-Turn Slot Filling           │  │
│  │  Voice Authentication │  │  - Claude Haiku (Optional Fallback)  │  │
│  └───────────────────────┘  └──────────────────────────────────────┘  │
└────────────────────────────────────┬───────────────────────────────────┘
                                     │ SQL Queries / Audio Files
                                     ▼
┌────────────────────────────────────────────────────────────────────────┐
│                       PERSISTENCE & STORAGE                           │
│  - SQLite (WAL mode, Foreign Keys ON): voxledger.db                   │
│  - Voice Biometric Samples: database/voice_samples/*.wav              │
│  - Speech Synthesis Cache: database/tts_cache/*.mp3                   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Directory Structure and Boundaries

```
VoxLedger_v17_Final_updated/
├── README.md                     # Project overview and quickstart
├── ARCHITECTURE.md               # Detailed system architecture (this file)
├── API_DOCUMENTATION.md          # REST API specifications and contracts
├── SETUP_GUIDE.md                # Development and production setup guide
├── .env.example                  # Root environment variables template
├── .gitignore                    # Comprehensive repository gitignore
│
├── VoxLedger_frontend/           # React + TypeScript Frontend Application
│   ├── index.html                # Single Page Application HTML root
│   ├── package.json              # NPM package definition and build scripts
│   ├── tsconfig.json             # TypeScript compiler configuration
│   ├── vite.config.ts            # Vite configuration with proxy integration
│   ├── tailwind.config.ts        # Tailwind CSS styling configuration
│   ├── postcss.config.js         # PostCSS configuration
│   ├── client/                   # Frontend source code
│   │   ├── main.tsx              # DOM root mount entrypoint
│   │   ├── App.tsx               # Primary application router & providers
│   │   ├── assets/               # Static icons and image assets
│   │   ├── styles/               # Global CSS and stylesheet definitions
│   │   │   └── global.css        # Tailwind directives and custom variables
│   │   ├── components/           # UI components
│   │   │   ├── Layout.tsx        # Persistent voice-assistant wrapper & mic engine
│   │   │   ├── SplashScreen.tsx  # Initial app launch & registration router
│   │   │   └── ui/               # Active Radix UI / shadcn component primitives
│   │   │       ├── button.tsx, card.tsx, dialog.tsx, input.tsx, label.tsx,
│   │   │       ├── progress.tsx, sonner.tsx, toast.tsx, toaster.tsx, tooltip.tsx
│   │   ├── context/              # State management
│   │   │   └── AppContext.tsx    # Global user, auth, tx, and budget state
│   │   ├── hooks/                # Custom React hooks
│   │   │   └── use-toast.ts      # Toast notification dispatch hook
│   │   ├── lib/                  # Utilities and API client
│   │   │   ├── api.ts            # Type-safe API client with session attachment
│   │   │   ├── utils.ts          # Class merging helper (clsx + tailwind-merge)
│   │   │   └── utils.spec.ts     # Vitest unit tests for utilities
│   │   └── pages/                # Application views
│   │       ├── Registration.tsx  # Voice onboarding & name enrollment
│   │       ├── WakePhraseSetup.tsx# Wake phrase configuration
│   │       ├── Locked.tsx        # Biometric lock screen & speaker verification
│   │       ├── Greeting.tsx      # Welcome audio & summary intro
│   │       ├── Index.tsx         # Main financial dashboard
│   │       ├── Transactions.tsx  # Transactions list, search, add, and delete
│   │       ├── Budget.tsx        # Budget categories and progress visualization
│   │       ├── Notifications.tsx # Alerts and notifications feed
│   │       ├── Alerts.tsx        # Categorized financial alert breakdown
│   │       ├── Conversation.tsx  # Hands-free assistant conversation history
│   │       ├── Profile.tsx       # User settings and profile management
│   │       ├── AddVoiceProfile.tsx# Additional voice sample enrollment
│   │       └── NotFound.tsx      # 404 error page
│   ├── server/                   # Production Node.js / Express server
│   │   └── index.ts              # Express reverse proxy & static file server
│   └── shared/                   # Shared types and configuration
│       ├── api-routes.ts         # Single source of truth for API routes
│       └── api.ts                # Shared API response interfaces
│
└── VoxLedger_backend/            # Python FastAPI Backend
    ├── main.py                   # FastAPI entrypoint, middleware, lifespan
    ├── config.py                 # Pydantic Settings with security validation
    ├── database.py               # SQLite connection factory & migrations
    ├── requirements.txt          # Python dependency specifications
    ├── .env.example              # Backend environment template
    ├── database/                 # Persistent storage directory
    │   ├── voxledger.db          # SQLite database (auto-created)
    │   ├── voice_samples/        # Raw WAV voice biometric enrollment files
    │   └── tts_cache/            # Synthesized speech audio cache
    ├── models/                   # Pydantic data schemas
    │   ├── user_model.py         # User, auth, and token models
    │   ├── transaction_model.py  # Transaction and financial summary models
    │   ├── budget_model.py       # Budget request and response models
    │   └── notification_model.py # Notification models
    ├── routes/                   # FastAPI route controllers
    │   ├── auth_routes.py        # Registration, check-user, voice verification
    │   ├── transaction_routes.py # Financial transactions (session-gated)
    │   ├── budget_routes.py      # Budget operations (session-gated)
    │   ├── notification_routes.py# Notifications & alerts (session-gated)
    │   └── voice_routes.py       # Voice command engine, intents, and TTS
    ├── services/                 # Business logic & AI pipelines
    │   ├── voice_auth_service.py # MFCC extraction, VAD, cosine verification
    │   ├── whisper_service.py    # OpenAI Whisper STT with Indian English fixes
    │   ├── tts_service.py        # gTTS audio generation with tempo acceleration
    │   ├── finance_service.py    # Ledger calculations & proactive alert rules
    │   ├── conversation_service.py# Multi-turn conversation persistence
    │   └── session_service.py    # Session token creation, lookup, and expiry
    ├── utils/                    # Reusable backend utilities
    │   ├── intent_parser.py      # Deterministic regex & keyword intent engine
    │   ├── ai_intent.py          # Claude API fallback intent interpreter
    │   ├── conversation_state.py # Multi-step transaction slot filler
    │   ├── date_parser.py        # Natural language date parsing (today/yesterday)
    │   └── session_auth.py       # FastAPI dependency enforcing X-Session-Token
    ├── scripts/                  # Calibration and maintenance utilities
    │   ├── calibrate_threshold.py# Speaker verification threshold derivation
    │   ├── reembed_voice_profiles.py# Re-extract embeddings with block norm
    │   └── reset_db.py           # Database cleanup utility
    └── tests/                    # Backend automated regression test suite
        └── test_full_suite.py    # Pytest test suite covering all endpoints
```

---

## 3. Frontend Architecture & State Management

### Persistent Layout Pattern
The application uses React Router v6 nested routes. `<Layout />` wraps all protected views (`/`, `/transactions`, `/budget`, `/notifications`, `/alerts`, `/profile`, `/conversation`):
- **Continuous Mic Monitoring**: The audio context and voice activity detector remain mounted during navigation.
- **Interruption Support**: Global audio playback can be interrupted immediately across any view when the user says "Stop" or triggers a stop event.
- **No Remount Latency**: Navigating between routes never unmounts or recalibrates the voice processing pipeline.

### State Flow & AppContext
`AppContext` serves as the single centralized state hub for:
1. `user`: Authenticated user profile and metadata.
2. `userId`: Active user identifier.
3. `isAuthenticated`: Boolean gating access to protected routes.
4. `transactions`: Array of financial records synchronized with SQLite.
5. `monthlyBudget`: Configured monthly budget ceiling.
6. `conversations`: Turn-by-turn chat history.
7. `sessionToken`: Stored in `sessionStorage` and attached via `X-Session-Token` header.

---

## 4. Authentication & Security Architecture

### Voice Biometric Verification Workflow
```
[User Speaks] 
      │
      ▼
[Stage 1-3: Quality Gate]
  - Silence Check: Low RMS energy (< 0.012) -> REJECT IMMEDIATELY
  - Voice Activity Detection (VAD): Multi-frame energy thresholding
  - Spectral Entropy: Rejects TV/music audio (threshold: 0.80)
      │
      ▼
[Stage 4: Wake Phrase Detection]
  - Verifies spoken phrase matches enrolled phrase ("hey vox" or custom)
      │
      ▼
[Stage 5: Feature Extraction]
  - 160 MFCC features (mean, std, delta, delta2 across 40 coefficients)
  - 5 Acoustic scalar features (pitch, spectral centroid, spectral rolloff)
  - Independent block L2-normalization prevents scalars from drowning MFCCs
      │
      ▼
[Stage 6: Multi-Sample Verification]
  - Compares cosine similarity with stored voice embeddings for the user
  - Requires:
      Score >= LOCK_VOICE_SIMILARITY_THRESHOLD (0.55)
      Consistency Floor >= 0.50
      │
      ▼
[Stage 7: Unlock & Session Issuance]
  - Backend issues a cryptographically secure 256-bit session token
  - Stores token with 7-day expiration in `sessions` table
  - Frontend attaches `X-Session-Token` to all future API calls
```

### Session Token Protection
To prevent bypassing voice authentication:
- Direct write/read endpoints (`/transactions/*`, `/budget/*`, `/notifications/*`) require `Depends(require_session)`.
- If a client makes calls without a valid token, the backend returns `401 Unauthorized`.
- Calling `POST /logout` immediately purges the session from the database.

---

## 5. Voice Assistant & Intent Engine

The voice pipeline supports both deterministic fast-path execution and flexible natural language understanding:

1. **Audio Ingestion**: Audio recorded at 16kHz mono WAV/WebM.
2. **Speech Recognition**: Local OpenAI Whisper STT (`small` model default) transcribes speech to text.
   - Includes Indian English pronunciation corrections (`"phi hundred"` -> `"500"`, `"lakh"`, `"k"`, etc.).
   - Rejects single-word non-financial hallucinations.
3. **Intent Classification**:
   - **Order of Evaluation**: Budget commands are analyzed *before* generic expense triggers to prevent "Set budget to 5000" from being recorded as an expense.
   - **Supported Intents**:
     - `add_expense` / `add_income`
     - `set_budget` / `get_budget`
     - `get_balance` / `list_transactions` / `summary`
     - `get_notifications` / `mark_read`
     - `navigate` (`"open budget"`, `"go to transactions"`)
     - `stop` (interrupts TTS playback immediately)
     - `undo` / `delete_last_transaction`
4. **Action Execution**: Directly updates SQLite in WAL mode.
5. **Speech Synthesis**: gTTS synthesizes spoken responses, dynamically accelerated using ffmpeg (`tempo=1.35x`) for natural cadence, and cached on disk.

---

## 6. Production Reverse Proxy Architecture

In production, Node.js serves both static frontend assets and reverse-proxies API calls:

- **Unified Route Configuration**: `shared/api-routes.ts` defines `API_PREFIXES` as a single shared constant imported by both `vite.config.ts` (dev proxy) and `server/index.ts` (production proxy).
- **Stream Preservation**: API requests are forwarded using Node's native `http.request` stream piping before Express body parsers consume the stream. This preserves:
  1. Multipart/form-data audio file uploads for voice biometric enrollment.
  2. Streaming chunked transfer responses for TTS audio.
- **Robust Path Resolution**: The production server resolves `dist/public` relative to `__dirname` (`path.resolve(__dirname, "../public")`), guaranteeing accurate static asset serving when invoked from any working directory.
