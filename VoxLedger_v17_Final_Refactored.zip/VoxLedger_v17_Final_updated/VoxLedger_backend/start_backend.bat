@echo off
title VoxLedger Backend v12.0
cd /d "%~dp0"
echo ===================================================
echo   VoxLedger Backend v12.0 - Starting...
echo ===================================================
echo.

if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
)

python -c "import fastapi" 2>nul || (
    echo Installing dependencies...
    pip install -r requirements.txt
)

echo   Backend URL:  http://localhost:8000
echo   API Docs:     http://localhost:8000/docs
echo.
echo ===================================================
uvicorn main:app --reload --host 0.0.0.0 --port 8000
