"""
Run this script to clear all user data and start fresh.
Usage: python scripts/reset_db.py
"""
import sys
import sqlite3
from pathlib import Path

# Add backend root to sys.path so settings can be imported
BACKEND_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_ROOT))

from config import settings


def reset_database():
    db_path = Path(settings.DATABASE_PATH)

    if db_path.exists():
        conn = sqlite3.connect(str(db_path))
        conn.execute("DELETE FROM voice_embeddings")
        conn.execute("DELETE FROM notifications")
        conn.execute("DELETE FROM transactions")
        conn.execute("DELETE FROM budgets")
        conn.execute("DELETE FROM conversation_history")
        conn.execute("DELETE FROM pending_intents")
        conn.execute("DELETE FROM user_settings")
        conn.execute("DELETE FROM sessions")
        conn.execute("DELETE FROM users")
        conn.commit()
        conn.close()
        print(f"✅ All user data cleared from {db_path}. You can now register fresh.")
    else:
        print(f"No database found at {db_path} — nothing to clear.")


if __name__ == "__main__":
    reset_database()
