"""
calibrate_threshold.py
-----------------------
Calibration script for speaker verification thresholds.

It re-extracts embeddings from stored raw voice samples (settings.VOICE_SAMPLE_DIR)
using the current _extract_embedding(), then reports:
  1. GENUINE similarity: every pair of samples belonging to the SAME user.
  2. IMPOSTOR similarity: every pair of samples belonging to DIFFERENT users.

Usage:
    python scripts/calibrate_threshold.py
"""
import itertools
import os
import sys
from pathlib import Path

# Add backend root to sys.path so modules resolve correctly
BACKEND_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_ROOT))

from database import get_connection
from services.voice_auth_service import _extract_embedding, _cosine_similarity


def main():
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT ve.user_id, ve.sample_path, u.name "
            "FROM voice_embeddings ve JOIN users u ON u.id = ve.user_id "
            "ORDER BY ve.user_id"
        ).fetchall()
    finally:
        conn.close()

    if not rows:
        print("No stored voice embeddings found.")
        return

    by_user = {}
    for row in rows:
        path = row["sample_path"]
        if not path or not os.path.exists(path):
            print(f"  skip (missing audio): user={row['name']} path={path!r}")
            continue
        with open(path, "rb") as f:
            audio_bytes = f.read()
        emb = _extract_embedding(audio_bytes)
        if emb is None:
            print(f"  skip (extraction failed): user={row['name']} path={path!r}")
            continue
        by_user.setdefault((row["user_id"], row["name"]), []).append(emb)

    genuine_scores = []
    for (uid, name), embs in by_user.items():
        for a, b in itertools.combinations(embs, 2):
            genuine_scores.append(_cosine_similarity(a, b))

    impostor_scores = []
    users = list(by_user.items())
    for (u1, embs1), (u2, embs2) in itertools.combinations(users, 2):
        for a in embs1:
            for b in embs2:
                impostor_scores.append(_cosine_similarity(a, b))

    def stats(name, vals):
        if not vals:
            print(f"{name}: no data")
            return None
        vals_sorted = sorted(vals)
        print(f"{name}: n={len(vals)} min={min(vals):.3f} "
              f"max={max(vals):.3f} mean={sum(vals)/len(vals):.3f} "
              f"median={vals_sorted[len(vals_sorted)//2]:.3f}")
        return vals

    print("\n=== GENUINE (same person, different sample) ===")
    g = stats("genuine", genuine_scores)

    print("\n=== IMPOSTOR (different people) ===")
    imp = stats("impostor", impostor_scores)

    print()
    if g and imp:
        worst_genuine = min(genuine_scores)
        best_impostor = max(impostor_scores)
        if worst_genuine <= best_impostor:
            print("⚠️  Genuine and impostor scores OVERLAP — no threshold can "
                  "perfectly separate them with this embedding. You'll have to "
                  "pick a tradeoff point, or improve the embedding (see note below).")
            suggestion = (worst_genuine + best_impostor) / 2
        else:
            suggestion = best_impostor + 0.3 * (worst_genuine - best_impostor)
        print(f"Suggested LOCK_VOICE_SIMILARITY_THRESHOLD ≈ {suggestion:.3f}")
        print(f"Suggested VOICE_SIMILARITY_ABSOLUTE_FLOOR ≈ {max(0.0, suggestion - 0.05):.3f}")
    elif g:
        worst_genuine = min(genuine_scores)
        print("No impostor data yet — set threshold no higher than the worst "
              f"genuine score ({worst_genuine:.3f}) minus a small margin, e.g. "
              f"~{max(0.0, worst_genuine - 0.05):.3f}, but re-run this script "
              "once you have a second voice's samples to check impostor separation.")

    print(
        "\nNote: if genuine and impostor scores overlap a lot, the real fix "
        "isn't the threshold — it's swapping the hand-crafted MFCC-stat "
        "embedding in _extract_embedding() for a pretrained speaker-embedding "
        "model (e.g. Resemblyzer or SpeechBrain's ECAPA-TDNN), which produces "
        "much better genuine/impostor separation on real mic audio."
    )


if __name__ == "__main__":
    main()
