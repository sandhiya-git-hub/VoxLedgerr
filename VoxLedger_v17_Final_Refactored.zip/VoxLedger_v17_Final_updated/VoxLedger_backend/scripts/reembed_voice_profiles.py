"""
v14 migration: re-extract voice embeddings from stored raw audio.

WHY THIS EXISTS
----------------
Before v14, _extract_embedding() concatenated raw-scale scalar features
together with MFCC statistics and L2-normalised the whole vector in one shot.
v14 fixes this by normalising each feature block independently before combining them.
This script re-extracts stored embeddings from the original saved audio files
(voice_embeddings.sample_path) using the current extractor.

USAGE
-----
    python scripts/reembed_voice_profiles.py
"""
import os
import pickle
import sys
from pathlib import Path

# Add backend root to sys.path
BACKEND_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_ROOT))

from database import get_connection
from services.voice_auth_service import _extract_embedding


def main():
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT id, user_id, sample_path FROM voice_embeddings ORDER BY user_id, id"
        ).fetchall()

        if not rows:
            print("No stored voice embeddings found — nothing to migrate.")
            return

        updated, skipped = 0, 0
        for row in rows:
            sample_path = row["sample_path"]
            if not sample_path or not os.path.exists(sample_path):
                print(f"  ⚠️  embedding id={row['id']} (user {row['user_id']}): "
                      f"no stored audio at {sample_path!r} — SKIPPED, please re-enroll this sample.")
                skipped += 1
                continue

            with open(sample_path, "rb") as f:
                audio_bytes = f.read()

            new_embedding = _extract_embedding(audio_bytes)
            if new_embedding is None:
                print(f"  ⚠️  embedding id={row['id']} (user {row['user_id']}): "
                      f"re-extraction failed from {sample_path!r} — SKIPPED, please re-enroll this sample.")
                skipped += 1
                continue

            conn.execute(
                "UPDATE voice_embeddings SET embedding = ? WHERE id = ?",
                (pickle.dumps(new_embedding), row["id"]),
            )
            updated += 1
            print(f"  ✅  embedding id={row['id']} (user {row['user_id']}): re-embedded ({len(new_embedding)}-dim).")

        conn.commit()
        print(f"\nDone. {updated} embedding(s) migrated, {skipped} skipped (need manual re-enrollment).")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
