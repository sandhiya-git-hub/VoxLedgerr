"""
require_session — FastAPI dependency for endpoints that must only be
callable after a successful voice unlock.

Usage (applied at router level so every route in that router is covered
without editing each function signature):

    router = APIRouter(prefix="/transactions", dependencies=[Depends(require_session)])

Reads the X-Session-Token header, checks it against the sessions table.
Raises 401 if missing/invalid/expired.
"""
from fastapi import Header, HTTPException
from services.session_service import get_session_user_id


def require_session(x_session_token: str = Header(default=None, alias="X-Session-Token")):
    if not x_session_token:
        raise HTTPException(
            status_code=401,
            detail="Missing session. Please unlock VoxLedger with your voice first.",
        )
    user_id = get_session_user_id(x_session_token)
    if user_id is None:
        raise HTTPException(
            status_code=401,
            detail="Session expired or invalid. Please unlock VoxLedger with your voice again.",
        )
    return user_id
