# VoxLedger Backend

A high-performance Python FastAPI service providing voice biometrics, Whisper speech recognition, deterministic intent execution, natural language understanding, financial ledger services, and text-to-speech synthesis.

---

## 1. Directory Structure

```
VoxLedger_backend/
├── main.py               # FastAPI application entrypoint, CORS, routers
├── config.py             # Pydantic Settings & environment validation
├── database.py           # SQLite connection manager & schema migrations
├── requirements.txt      # Python dependencies
├── .env.example          # Environment variables template
├── database/             # Persistent SQLite database & audio storage
│   ├── voxledger.db      # SQLite database file
│   ├── voice_samples/    # Stored enrollment WAV audio files
│   └── tts_cache/        # Cached synthesized MP3 audio files
├── models/               # Pydantic data models & request/response schemas
│   ├── user_model.py     # User registration and authentication models
│   ├── transaction_model.py # Transactions & financial summary models
│   ├── budget_model.py   # Budget models
│   └── notification_model.py # Notification models
├── routes/               # API route controllers
│   ├── auth_routes.py    # Registration, user check, voice verification
│   ├── transaction_routes.py # Financial transactions (session-gated)
│   ├── budget_routes.py  # Budget operations (session-gated)
│   ├── notification_routes.py # Notifications & alerts (session-gated)
│   └── voice_routes.py   # Voice & text commands, STT, and TTS
├── services/             # Core business logic & AI pipelines
│   ├── voice_auth_service.py # MFCC extraction, VAD, cosine verification
│   ├── whisper_service.py # Whisper speech recognition
│   ├── tts_service.py    # gTTS synthesis with ffmpeg tempo scaling
│   ├── finance_service.py# Accounting ledger and alert rules
│   ├── conversation_service.py # Multi-turn conversational history
│   └── session_service.py # Cryptographic session tokens
├── utils/                # Reusable utilities
│   ├── intent_parser.py  # Deterministic intent matching engine
│   ├── ai_intent.py      # Claude AI fallback integration
│   ├── conversation_state.py # Transaction slot filling
│   ├── date_parser.py    # Date and time parsing
│   └── session_auth.py   # FastAPI dependency for X-Session-Token
├── scripts/              # Maintenance and calibration utilities
│   ├── calibrate_threshold.py # Threshold calibration tool
│   ├── reembed_voice_profiles.py # Vector embedding migration tool
│   └── reset_db.py       # Safe database reset utility
└── tests/                # Automated regression test suite
    └── test_full_suite.py# Pytest test suite covering all endpoints
```

---

## 2. Key Services & Features

1. **Voice Biometric Authentication (`services/voice_auth_service.py`)**:
   - 165-dimensional feature vector combining 160 MFCC statistics (mean, std, delta, delta2 across 40 coefficients) with 5 pitch and spectral scalars.
   - Independent block L2 normalization prevents scalar features from dominating speaker identity.
   - Strict VAD, energy floor, and spectral entropy validation reject silence, background TV, and synthetic playback.
2. **Speech Recognition (`services/whisper_service.py`)**:
   - Local OpenAI Whisper STT with greedy decoding and Indian English financial normalization.
3. **Session Authentication (`utils/session_auth.py`)**:
   - Write and transaction endpoints require a valid `X-Session-Token` issued only upon successful voice unlock.
4. **Deterministic Intent Classification (`utils/intent_parser.py`)**:
   - Evaluates budget commands prior to expense triggers to prevent misclassification.
5. **Database Storage (`database.py`)**:
   - SQLite with WAL (Write-Ahead Logging) mode and foreign key enforcement.

---

## 3. Running & Testing

```bash
# Start backend server
uvicorn main:app --reload --port 8000

# Run automated test suite
pytest tests/test_full_suite.py -v
```
