import warnings
from pathlib import Path
from pydantic import model_validator
from pydantic_settings import BaseSettings

# Application base directory — all paths are resolved relative to this directory,
# ensuring full independence from the terminal's current working directory.
BASE_DIR = Path(__file__).resolve().parent


class Settings(BaseSettings):
    APP_NAME: str = "VoxLedger API"
    APP_VERSION: str = "12.0.0"
    DEBUG: bool = True
    ENVIRONMENT: str = "development"

    # Database
    DATABASE_URL: str = f"sqlite:///{BASE_DIR}/database/voxledger.db"
    DATABASE_PATH: str = str(BASE_DIR / "database" / "voxledger.db")

    # Auth
    SECRET_KEY: str = "voxledger-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

    # Voice Storage
    VOICE_SAMPLE_DIR: str = str(BASE_DIR / "database" / "voice_samples")

    # ── v15: Threshold recalibrated against REAL microphone audio ─────────────
    # LOCK_VOICE_SIMILARITY_THRESHOLD: unlock threshold — the PRIMARY gate
    # that decides whether the app unlocks.
    LOCK_VOICE_SIMILARITY_THRESHOLD: float = 0.55

    # VOICE_SIMILARITY_THRESHOLD: general in-app voice matching (non-unlock)
    VOICE_SIMILARITY_THRESHOLD: float = 0.55

    # Absolute floor — no adaptive/lenient logic may ever authenticate below this,
    # regardless of sample-count bonuses. Prevents "1 sample = big discount" abuse.
    VOICE_SIMILARITY_ABSOLUTE_FLOOR: float = 0.50

    # Max allowed spectral entropy before audio is treated as TV/music/broadcast
    # rather than a live human voice.
    SPECTRAL_ENTROPY_MAX: float = 0.80

    # Max stored embeddings per user (name-phrase + wake-phrase + manual additions)
    MAX_VOICE_SAMPLES: int = 10

    # STT model — small gives best accuracy for names and finance terms
    WHISPER_MODEL: str = "small"

    # TTS
    TTS_LANGUAGE: str = "en"
    TTS_DIR: str = str(BASE_DIR / "database" / "tts_cache")
    TTS_SPEED: float = 1.35   # natural speech rate

    # Currency
    CURRENCY_SYMBOL: str = "₹"
    CURRENCY_CODE: str = "INR"

    # Budget alert thresholds
    BUDGET_WARNING_PCT: float = 0.80   # 80% = warning
    BUDGET_CRITICAL_PCT: float = 0.95  # 95% = critical

    @model_validator(mode="after")
    def validate_security(self) -> "Settings":
        is_prod = (not self.DEBUG) or (self.ENVIRONMENT.lower() == "production")
        insecure_default = "voxledger-secret-key-change-in-production"
        if is_prod and (not self.SECRET_KEY or self.SECRET_KEY == insecure_default):
            raise ValueError(
                "SECRET_KEY must be configured with a secure random key when DEBUG is False or ENVIRONMENT is production."
            )
        if self.SECRET_KEY == insecure_default:
            warnings.warn(
                "Running with default insecure SECRET_KEY. Set a unique SECRET_KEY in production.",
                UserWarning,
                stacklevel=2,
            )
        return self

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
