#!/bin/bash
# VoxLedger Backend Startup Script

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "═══════════════════════════════════════════════════"
echo "  VoxLedger Backend v12.0 — Starting..."
echo "═══════════════════════════════════════════════════"

# Check Python
if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 not found. Please install Python 3.10+"
    exit 1
fi

# Check ffmpeg
if ! command -v ffmpeg &>/dev/null; then
    echo "WARNING: ffmpeg not found. Voice processing may not work."
    echo "Install: sudo apt install ffmpeg   (Ubuntu)"
    echo "         brew install ffmpeg        (macOS)"
fi

# Create database directory
mkdir -p database/voice_samples
mkdir -p database/tts_cache

# Check for virtual environment
if [ -d "venv" ]; then
    echo "Activating virtual environment..."
    source venv/bin/activate
fi

# Check dependencies
python3 -c "import fastapi" 2>/dev/null || {
    echo "Installing dependencies..."
    pip install -r requirements.txt
}

echo ""
echo "  Backend URL:  http://localhost:8000"
echo "  API Docs:     http://localhost:8000/docs"
echo ""
echo "  Whisper STT:  $(python3 -c 'import whisper; print("✅ Available")' 2>/dev/null || echo "⚠️  Not installed (pip install openai-whisper)")"
echo "  Librosa:      $(python3 -c 'import librosa; print("✅ Available")' 2>/dev/null || echo "⚠️  Not installed (voice auth fallback active)")"
echo ""

# Check for API key
if [ -z "$ANTHROPIC_API_KEY" ]; then
    echo "  AI Intent:    ⚠️  ANTHROPIC_API_KEY not set (keyword parser active)"
else
    echo "  AI Intent:    ✅ Claude Haiku active"
fi

echo ""
echo "═══════════════════════════════════════════════════"

uvicorn main:app --reload --host 0.0.0.0 --port 8000
