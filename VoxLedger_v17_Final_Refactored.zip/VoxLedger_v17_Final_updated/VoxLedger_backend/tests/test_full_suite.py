"""
Full automated regression test suite for VoxLedger backend.
Tests all endpoints, security gates, audio handling, intent parsing,
session lifecycle, and database integrity.
"""
import io
import os
import sys
import math
import struct
import wave
import pytest
from pathlib import Path
from fastapi.testclient import TestClient

# Ensure backend root is on sys.path
BACKEND_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BACKEND_ROOT))

from main import app
from database import init_db, get_connection
from config import settings
from utils.intent_parser import parse_intent


def create_test_wav(duration_sec=2.0, freq=300.0, is_silence=False) -> bytes:
    """Generate in-memory WAV audio bytes for testing."""
    sample_rate = 16000
    num_samples = int(sample_rate * duration_sec)
    buf = io.BytesIO()

    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        if is_silence:
            # Low ambient noise / silence
            data = struct.pack(f"<{num_samples}h", *([0] * num_samples))
        else:
            # Multi-frequency modulated wave to simulate speech energy
            samples = []
            for i in range(num_samples):
                t = i / sample_rate
                val = 0.5 * math.sin(2 * math.pi * freq * t) + 0.3 * math.sin(2 * math.pi * (freq * 2.1) * t)
                # Amplitude envelope
                env = math.sin(math.pi * t / duration_sec)
                sample_val = int(val * env * 16000)
                samples.append(max(-32767, min(32767, sample_val)))
            data = struct.pack(f"<{num_samples}h", *samples)
        wf.writeframes(data)

    return buf.getvalue()


@pytest.fixture(scope="session")
def client():
    init_db()
    with TestClient(app) as c:
        yield c


def test_01_health_and_root(client):
    r_root = client.get("/")
    assert r_root.status_code == 200
    assert r_root.json()["status"] == "running"

    r_health = client.get("/health")
    assert r_health.status_code == 200
    assert r_health.json()["status"] == "ok"


def test_02_registration_and_check_user(client):
    import time
    user_name = f"User_{int(time.time())}"
    # Register user
    r_reg = client.post("/register", data={"name": user_name, "password": "securepass123"})
    assert r_reg.status_code == 200
    data = r_reg.json()
    assert data["success"] is True
    user_id = data["user_id"]
    assert user_id > 0

    # Check user endpoint returns valid registration state
    r_check = client.get("/check-user")
    assert r_check.status_code == 200
    check_data = r_check.json()
    assert check_data["has_user"] is True
    assert isinstance(check_data["registered"], bool)
    assert isinstance(check_data["has_voice_profile"], bool)


def test_03_voice_enrollment_and_wake_phrase(client):
    # Retrieve user id
    conn = get_connection()
    user = conn.execute("SELECT id FROM users ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    assert user is not None
    user_id = user["id"]

    # Upload voice sample
    audio_wav = create_test_wav(duration_sec=2.5, freq=220.0)
    files = {"voice_sample": ("sample.wav", audio_wav, "audio/wav")}
    r_sample = client.post("/register/voice-sample", data={"user_id": str(user_id)}, files=files)
    assert r_sample.status_code == 200
    assert r_sample.json()["success"] is True

    # Verify check-user now reports fully registered with voice profile
    r_check = client.get("/check-user")
    assert r_check.status_code == 200
    assert r_check.json()["registered"] is True
    assert r_check.json()["has_voice_profile"] is True

    # Set wake phrase
    r_wake = client.post("/set-wake-phrase", data={"user_id": str(user_id), "wake_phrase": "hey vox"})
    assert r_wake.status_code == 200
    assert r_wake.json()["wake_phrase"] == "hey vox"


def test_04_silence_rejection(client):
    # Silence must NEVER authenticate a user
    silence_wav = create_test_wav(duration_sec=2.0, is_silence=True)
    files = {"voice_sample": ("silence.wav", silence_wav, "audio/wav")}
    r_verify = client.post("/verify-voice", files=files, data={"wake_phrase": "hey vox"})
    assert r_verify.status_code == 200
    data = r_verify.json()
    assert data["authenticated"] is False, "Silence should never authenticate a user!"


def test_05_session_auth_gate(client):
    conn = get_connection()
    user = conn.execute("SELECT id FROM users ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    user_id = user["id"]

    # Without session token -> 401 Unauthorized
    r_unauth = client.get(f"/transactions?user_id={user_id}")
    assert r_unauth.status_code == 401

    # With invalid session token -> 401 Unauthorized
    r_bad = client.get(f"/transactions?user_id={user_id}", headers={"X-Session-Token": "invalid-token"})
    assert r_bad.status_code == 401


def test_06_transactions_and_budget_lifecycle(client):
    from services.session_service import create_session

    conn = get_connection()
    user = conn.execute("SELECT id FROM users ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    user_id = user["id"]

    # Issue a valid session token for testing authenticated operations
    token = create_session(user_id)
    headers = {"X-Session-Token": token}

    # Add expense
    r_exp = client.post(
        "/transactions/add-expense",
        json={"user_id": user_id, "amount": 650.0, "category": "Food", "description": "Dinner with friends"},
        headers=headers,
    )
    assert r_exp.status_code == 200
    assert r_exp.json()["success"] is True
    tx_id = r_exp.json()["transaction"]["id"]

    # Add income
    r_inc = client.post(
        "/transactions/add-income",
        json={"user_id": user_id, "amount": 25000.0, "category": "Salary", "description": "Monthly pay"},
        headers=headers,
    )
    assert r_inc.status_code == 200
    assert r_inc.json()["success"] is True

    # List transactions
    r_list = client.get(f"/transactions?user_id={user_id}", headers=headers)
    assert r_list.status_code == 200
    assert len(r_list.json()["transactions"]) >= 2

    # Summary
    r_sum = client.get(f"/transactions/summary?user_id={user_id}", headers=headers)
    assert r_sum.status_code == 200
    assert r_sum.json()["total_income"] >= 25000.0

    # Set Budget
    r_bset = client.post(
        "/budget/set",
        json={"user_id": user_id, "category": "monthly", "amount": 30000.0},
        headers=headers,
    )
    assert r_bset.status_code == 200

    # Get Budget
    r_bget = client.get(f"/budget?user_id={user_id}", headers=headers)
    assert r_bget.status_code == 200
    assert r_bget.json()["monthly_budget"] == 30000.0

    # Delete transaction
    r_del = client.delete(f"/transactions/{tx_id}?user_id={user_id}", headers=headers)
    assert r_del.status_code == 200

    # Logout
    r_logout = client.post("/logout", headers=headers)
    assert r_logout.status_code == 200

    # Post-logout token check: must be 401
    r_post_logout = client.get(f"/transactions?user_id={user_id}", headers=headers)
    assert r_post_logout.status_code == 401


def test_07_intent_parsing_logic():
    # Budget setting must NOT be mistaken for an expense
    budget_intent = parse_intent("Set monthly budget to 20000")
    assert budget_intent["intent"] == "set_budget"
    assert budget_intent["amount"] == 20000.0

    cat_budget = parse_intent("Set food budget to 3000")
    assert cat_budget["intent"] == "set_budget"
    assert cat_budget["amount"] == 3000.0
    assert cat_budget["category"] == "Food"

    # Financial transaction
    expense_intent = parse_intent("Spent 450 on groceries")
    assert expense_intent["intent"] == "add_expense"
    assert expense_intent["amount"] == 450.0

    # Stop command
    stop_intent = parse_intent("stop")
    assert stop_intent["intent"] == "stop"


def test_08_tts_endpoint(client):
    r_tts = client.get("/voice/tts?text=Welcome+to+VoxLedger")
    assert r_tts.status_code == 200
    assert len(r_tts.content) > 0


if __name__ == "__main__":
    pytest.main(["-v", __file__])
