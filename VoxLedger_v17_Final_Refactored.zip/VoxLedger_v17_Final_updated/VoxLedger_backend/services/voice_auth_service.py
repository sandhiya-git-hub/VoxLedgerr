"""
Voice authentication service — v8.0 (intelligent assistant upgrade)

Key improvements:
  1. Enhanced VAD: rejects background music, TV audio, ambient speech
     using spectral entropy + zero-crossing rate + pitch continuity checks.
  2. Multi-sample averaging: when user has ≥3 samples, uses ensemble scoring
     with consistency check to reduce false accepts from TV/audio playback.
  3. Adaptive thresholds: scales confidence requirement with sample count.
  4. analyze_audio_quality: added background noise pattern detection.
  5. _extract_embedding: added spectral entropy features for better
     discrimination between human voice and recorded/broadcast audio.
  6. verify_voice: improved rejection logic for non-human audio sources.
"""
import io
import os
import pickle
import subprocess
import tempfile
import numpy as np
from typing import Optional, Tuple, List
from pathlib import Path

try:
    import librosa
    LIBROSA_AVAILABLE = True
except ImportError:
    LIBROSA_AVAILABLE = False

try:
    import soundfile as sf
    SOUNDFILE_AVAILABLE = True
except ImportError:
    SOUNDFILE_AVAILABLE = False

from config import settings
from database import get_connection


def _detect_format(audio_bytes: bytes) -> str:
    if audio_bytes[:4] == b'RIFF':
        return '.wav'
    if audio_bytes[:3] == b'ID3' or audio_bytes[:2] == b'\xff\xfb':
        return '.mp3'
    if audio_bytes[:4] == b'OggS':
        return '.ogg'
    return '.webm'


def _try_ffmpeg_convert(audio_bytes: bytes, ext: str) -> Optional[bytes]:
    """Convert audio to 16kHz mono WAV using ffmpeg if available."""
    try:
        with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp_in:
            tmp_in.write(audio_bytes)
            in_path = tmp_in.name

        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_out:
            out_path = tmp_out.name

        result = subprocess.run(
            ["ffmpeg", "-y", "-i", in_path, "-ar", "16000", "-ac", "1",
             "-f", "wav", out_path],
            capture_output=True, timeout=15
        )
        os.unlink(in_path)

        if result.returncode == 0 and os.path.getsize(out_path) > 100:
            with open(out_path, 'rb') as f:
                wav_bytes = f.read()
            os.unlink(out_path)
            return wav_bytes

        if os.path.exists(out_path):
            os.unlink(out_path)
    except Exception as e:
        print(f"[voice_auth] ffmpeg conversion failed: {e}")
    return None


def _load_audio(audio_bytes: bytes) -> Optional[Tuple[np.ndarray, int]]:
    """Load audio bytes into (samples, sample_rate). Tries multiple strategies."""
    ext = _detect_format(audio_bytes)

    # Strategy 1: Convert to WAV via ffmpeg, then load
    wav_bytes = _try_ffmpeg_convert(audio_bytes, ext)
    if wav_bytes and LIBROSA_AVAILABLE:
        try:
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
                tmp.write(wav_bytes)
                tmp_path = tmp.name
            y, sr = librosa.load(tmp_path, sr=16000, mono=True)
            os.unlink(tmp_path)
            if len(y) > 0:
                print(f"[voice_auth] Loaded via ffmpeg+librosa: {len(y)} samples at {sr}Hz")
                return y, sr
        except Exception as e:
            print(f"[voice_auth] ffmpeg+librosa failed: {e}")
            try: os.unlink(tmp_path)
            except: pass

    # Strategy 2: librosa direct
    if LIBROSA_AVAILABLE:
        try:
            with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
                tmp.write(audio_bytes)
                tmp_path = tmp.name
            y, sr = librosa.load(tmp_path, sr=16000, mono=True)
            os.unlink(tmp_path)
            if len(y) > 0:
                print(f"[voice_auth] Loaded via librosa direct: {len(y)} samples")
                return y, sr
        except Exception as e:
            print(f"[voice_auth] librosa direct load failed ({ext}): {e}")
            try: os.unlink(tmp_path)
            except: pass

    # Strategy 3: soundfile
    if SOUNDFILE_AVAILABLE and ext in ('.wav', '.ogg', '.flac'):
        try:
            y, sr = sf.read(io.BytesIO(audio_bytes))
            if y.ndim > 1:
                y = y.mean(axis=1)
            y = y.astype(np.float32)
            print(f"[voice_auth] Loaded via soundfile: {len(y)} samples at {sr}Hz")
            return y, sr
        except Exception as e:
            print(f"[voice_auth] soundfile failed: {e}")

    # Strategy 3b: soundfile on ffmpeg-converted WAV
    if SOUNDFILE_AVAILABLE and wav_bytes:
        try:
            y, sr = sf.read(io.BytesIO(wav_bytes))
            if y.ndim > 1:
                y = y.mean(axis=1)
            y = y.astype(np.float32)
            print(f"[voice_auth] Loaded via soundfile+ffmpeg: {len(y)} samples")
            return y, sr
        except Exception as e:
            print(f"[voice_auth] soundfile+ffmpeg failed: {e}")

    # Strategy 4: Raw WAV parsing
    if ext == '.wav' or audio_bytes[:4] == b'RIFF':
        try:
            import wave
            with wave.open(io.BytesIO(audio_bytes)) as wf:
                frames = wf.readframes(wf.getnframes())
                sr = wf.getframerate()
                dtype = np.int16 if wf.getsampwidth() == 2 else np.int32
                y = np.frombuffer(frames, dtype=dtype).astype(np.float32)
                y /= np.iinfo(dtype).max
                print(f"[voice_auth] Loaded via wave module: {len(y)} samples at {sr}Hz")
                return y, sr
        except Exception as e:
            print(f"[voice_auth] wave parse failed: {e}")

    print("[voice_auth] All audio loading strategies failed")
    return None


def analyze_audio_quality(audio_bytes: bytes) -> Tuple[bool, str, Optional[np.ndarray], int]:
    """
    Voice Activity Detection / quality gate — v8.0

    Enhanced to reject:
    - Background voices / TV / radio (using spectral entropy)
    - Pure ambient noise (low dynamic range)
    - Silence (low RMS)
    - Non-speech audio (ZCR + voiced duration checks)

    FIX v8: Added spectral entropy check to distinguish live human voice
    from broadcast audio. Human voice has lower spectral entropy than music/TV.
    Thresholds tuned for browser microphone (echoCancellation + noiseSuppression).
    """
    audio = _load_audio(audio_bytes)
    if audio is None or not LIBROSA_AVAILABLE:
        return False, "No speech detected. Please speak again.", None, 0

    y, sr = audio
    if y is None or len(y) == 0:
        return False, "No speech detected. Please speak again.", None, 0

    y = y.astype(np.float32)
    peak = float(np.max(np.abs(y))) if len(y) else 0.0
    if peak > 0:
        y = y / peak

    duration_sec = len(y) / max(sr, 1)
    if duration_sec < 0.35:  # v8 FIX: was 0.6 — "Hey Vox" is ~0.4–0.5s, must not be rejected
        return False, "No speech detected. Please speak again.", y, sr

    overall_rms = float(np.sqrt(np.mean(np.square(y)))) if len(y) else 0.0
    if overall_rms < 0.008:
        return False, "No speech detected. Please speak again.", y, sr

    frame_length = max(512, int(sr * 0.03))
    hop_length = max(256, int(sr * 0.015))

    try:
        intervals = librosa.effects.split(y, top_db=30)
        voiced_parts = [(s, e) for s, e in intervals if (e - s) >= int(0.05 * sr)]
        voiced_samples = sum(int(e - s) for s, e in voiced_parts)
    except Exception:
        voiced_parts = []
        voiced_samples = 0

    voiced_duration = voiced_samples / max(sr, 1)
    if voiced_parts:
        y_active = np.concatenate([y[s:e] for s, e in voiced_parts])
    else:
        y_active = y

    try:
        rms_frames = librosa.feature.rms(y=y_active, frame_length=frame_length, hop_length=hop_length)[0]
    except Exception:
        rms_frames = np.array([], dtype=np.float32)

    if rms_frames.size == 0:
        return False, "Could not analyse speech activity.", y, sr

    ambient = float(np.percentile(rms_frames, 15))
    loud = float(np.percentile(rms_frames, 85))
    vad_threshold = max(0.012, ambient * 2.0, loud * 0.28)
    speech_mask = rms_frames >= vad_threshold
    speech_frames = int(np.sum(speech_mask))
    speech_ratio = speech_frames / max(len(rms_frames), 1)

    speech_runs: List[int] = []
    run = 0
    for is_speech in speech_mask.tolist():
        if is_speech:
            run += 1
        elif run:
            speech_runs.append(run)
            run = 0
    if run:
        speech_runs.append(run)
    longest_speech_run = max(speech_runs) if speech_runs else 0
    longest_speech_sec = (longest_speech_run * hop_length) / max(sr, 1)

    try:
        zcr = librosa.feature.zero_crossing_rate(y_active, frame_length=frame_length, hop_length=hop_length)[0]
        zcr_mean = float(np.mean(zcr)) if zcr.size else 0.0
    except Exception:
        zcr_mean = 0.0

    try:
        flatness = librosa.feature.spectral_flatness(y=y_active, n_fft=frame_length, hop_length=hop_length)[0]
        flatness_mean = float(np.mean(flatness)) if flatness.size else 0.0
    except Exception:
        flatness_mean = 0.0

    # Sufficient voiced region — v8: lowered from 0.35s/0.15s to allow "Hey Vox" (~0.4s)
    if voiced_duration >= 0.15 and longest_speech_sec >= 0.08:
        return True, "ok", y, sr

    # ── v8: Spectral entropy check — distinguishes live voice from TV/music ──
    # Human speech has moderate spectral entropy. Music/TV has high entropy
    # (many frequency components at once). Pure noise also has high entropy.
    spectral_entropy = 0.5  # neutral default
    try:
        stft = np.abs(librosa.stft(y_active, n_fft=frame_length, hop_length=hop_length))
        # Normalise each frame to probability distribution
        stft_sum = stft.sum(axis=0, keepdims=True)
        stft_sum = np.where(stft_sum == 0, 1e-10, stft_sum)
        stft_norm = stft / stft_sum
        stft_norm = np.where(stft_norm == 0, 1e-10, stft_norm)
        frame_entropy = -np.sum(stft_norm * np.log2(stft_norm + 1e-10), axis=0)
        max_entropy = np.log2(stft.shape[0])
        spectral_entropy = float(np.mean(frame_entropy) / max(max_entropy, 1e-6))
    except Exception:
        pass

    dynamic_range = loud / max(ambient, 1e-6)

    print(f"[voice_auth] Quality check: voiced_dur={voiced_duration:.2f}s, speech_frames={speech_frames}, "
          f"speech_ratio={speech_ratio:.2f}, longest_run={longest_speech_sec:.2f}s, "
          f"dynamic_range={dynamic_range:.2f}, flatness={flatness_mean:.3f}, "
          f"zcr={zcr_mean:.3f}, spectral_entropy={spectral_entropy:.3f}")

    # Basic speech presence check — v8: lowered thresholds so short phrases ("Hey Vox") pass
    if speech_frames < 2 or speech_ratio < 0.03 or voiced_duration < 0.10 or longest_speech_sec < 0.08:
        return False, "No speech detected. Please speak again.", y, sr

    # ── v13: TV/music/background/replay audio rejection ─────────────────────
    # TV/music typically has very high spectral entropy because many frequency
    # bins are active simultaneously. Live human voice is normally < 0.80.
    # v13 tightened this cap (was 0.85) per security audit — replayed / speaker-
    # played audio was slipping through the old threshold.
    entropy_cap = float(getattr(settings, "SPECTRAL_ENTROPY_MAX", 0.80))
    if spectral_entropy > entropy_cap:
        print(f"[voice_auth] ⚠️  High spectral entropy ({spectral_entropy:.3f} > {entropy_cap}) — possible TV/music/background audio")
        return False, "Background noise detected. Please move to a quieter environment.", y, sr

    # ── v13: Liveness / anti-replay heuristic ───────────────────────────────
    # Genuine live speech has natural pitch and energy micro-variation.
    # Perfectly flat pitch + perfectly uniform frame energy over a long
    # duration is characteristic of synthetic TTS audio or a low-quality
    # speaker replay, not a live human speaking into a microphone.
    try:
        if len(y_active) / max(sr, 1) >= 0.5:
            frame_rms = rms_frames[rms_frames > 0]
            energy_cv = float(np.std(frame_rms) / np.mean(frame_rms)) if frame_rms.size and np.mean(frame_rms) > 0 else 1.0
            if energy_cv < 0.08:
                print(f"[voice_auth] ⚠️  Suspiciously uniform energy (cv={energy_cv:.3f}) — possible synthetic/replay audio")
                return False, "Authentication failed. Only the registered user's voice can access this application.", y, sr
    except Exception:
        pass

    # Sufficient voiced region → skip remaining heuristics
    if voiced_duration >= 0.35 and longest_speech_sec >= 0.15:
        return True, "ok", y, sr

    if dynamic_range < 1.08:
        return False, "Background noise detected. Please move to a quieter environment.", y, sr

    if flatness_mean > 0.65:
        return False, "Background noise detected. Please move to a quieter environment.", y, sr

    if zcr_mean < 0.0005 or zcr_mean > 0.45:
        return False, "No speech detected. Please speak again.", y, sr

    return True, "ok", y, sr


def _extract_embedding(audio_bytes: bytes) -> Optional[np.ndarray]:
    """Extract voice embedding from audio bytes. Returns 1D numpy array or None."""
    ok, reason, y, sr = analyze_audio_quality(audio_bytes)
    if not ok or y is None or not LIBROSA_AVAILABLE:
        print(f"[voice_auth] Sample rejected by quality gate: {reason}")
        return None

    y = y - float(np.mean(y))
    peak = float(np.max(np.abs(y))) if len(y) else 0.0
    if peak <= 1e-6:
        print("[voice_auth] Silent audio after DC removal")
        return None
    y = y / peak

    try:
        # FIX v5: use top_db=15 for VAD — browser mic compression means quieter speech
        intervals = librosa.effects.split(y, top_db=15)
        if intervals is None or len(intervals) == 0:
            print("[voice_auth] No voiced region found")
            return None
        # FIX v5: lowered minimum voiced segment from 0.05s to 0.03s
        voiced_parts = [y[s:e] for s, e in intervals if (e - s) >= int(0.03 * sr)]
        if not voiced_parts:
            print("[voice_auth] No long enough voiced region found")
            return None
        voiced = np.concatenate(voiced_parts)
        # FIX v5: lowered minimum voiced total from 0.4s to 0.25s
        if len(voiced) < int(0.25 * sr):
            print(f"[voice_auth] Voiced region too short: {len(voiced)/sr:.2f}s")
            return None
        y = voiced
    except Exception as e:
        print(f"[voice_auth] Voice activity split failed: {e}")

    try:
        # MFCC (40 coefficients) → mean + std + delta + delta2 → 160-dim
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40)
        delta = librosa.feature.delta(mfcc)
        delta2 = librosa.feature.delta(mfcc, order=2)

        mfcc_mean = np.mean(mfcc, axis=1)
        mfcc_std = np.std(mfcc, axis=1)
        delta_mean = np.mean(delta, axis=1)
        delta2_mean = np.mean(delta2, axis=1)

        # Pitch features
        pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
        pitch_vals = pitches[magnitudes > np.mean(magnitudes)]
        pitch_mean = float(np.mean(pitch_vals)) if len(pitch_vals) > 0 else 0.0
        pitch_std = float(np.std(pitch_vals)) if len(pitch_vals) > 0 else 0.0

        # Spectral features
        spec_centroid = float(np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)))
        spec_rolloff = float(np.mean(librosa.feature.spectral_rolloff(y=y, sr=sr)))
        zcr = float(np.mean(librosa.feature.zero_crossing_rate(y)))
        scalar_block = np.array([pitch_mean, pitch_std, spec_centroid, spec_rolloff, zcr], dtype=np.float64)

        # ── FIX (critical): per-block L2 normalisation before concatenation ──
        # BUG: pitch/centroid/rolloff are raw Hz values (magnitude ~1000s),
        # while MFCC-derived stats are magnitude ~10s-100s. Concatenating raw
        # values and L2-normalising the WHOLE vector let the 5 scalar features
        # dominate >99% of the vector's energy — the 160 MFCC dimensions that
        # actually encode vocal-tract / speaker-identity timbre were almost
        # entirely drowned out. Cosine similarity then mostly compared pitch
        # register, not speaker identity, which let different speakers with a
        # similar pitch/spectral-tilt register score ~0.99+ against each
        # other — a severe false-accept risk. FIX: normalise each
        # conceptually distinct feature block to unit norm independently, so
        # every block contributes on equal footing regardless of its raw
        # physical units, before combining into the final embedding.
        def _unit(v: np.ndarray) -> np.ndarray:
            n = np.linalg.norm(v)
            return v / n if n > 1e-9 else v

        features = np.concatenate([
            _unit(mfcc_mean),
            _unit(mfcc_std),
            _unit(delta_mean),
            _unit(delta2_mean),
            _unit(scalar_block),
        ]).astype(np.float64)  # 165-dim, each block unit-norm before final norm

        norm = np.linalg.norm(features)
        if norm > 0:
            features = features / norm

        print(f"[voice_auth] Extracted {len(features)}-dim embedding (block-normalised)")
        return features.astype(np.float32)

    except Exception as e:
        print(f"[voice_auth] Feature extraction failed: {e}")
        return None


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    min_len = min(len(a), len(b))
    a, b = a[:min_len], b[:min_len]
    dot = np.dot(a, b)
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    return float(dot / denom) if denom > 0 else 0.0


# ── Public API ────────────────────────────────────────────────────────────────

def save_voice_embedding(user_id: int, audio_bytes: bytes) -> Tuple[bool, str]:
    """
    FIX: Only saves voice embedding after passing quality gate AND feature extraction.
    If either fails, returns a descriptive error — never stores a noisy/silent sample.
    """
    conn = get_connection()
    try:
        count = conn.execute(
            "SELECT COUNT(*) as cnt FROM voice_embeddings WHERE user_id = ?",
            (user_id,)
        ).fetchone()["cnt"]

        if count >= settings.MAX_VOICE_SAMPLES:
            return False, f"Maximum {settings.MAX_VOICE_SAMPLES} voice samples already registered."

        # FIX: quality gate runs BEFORE embedding extraction — reject early
        ok, reason, _, _ = analyze_audio_quality(audio_bytes)
        if not ok:
            print(f"[voice_auth] Registration rejected (quality): {reason}")
            return False, reason

        embedding = _extract_embedding(audio_bytes)
        if embedding is None:
            return False, "Could not extract voice features. Audio may be too short, silent, or noisy. Please try again in a quiet environment."

        blob = pickle.dumps(embedding)

        # Save raw audio file for debugging
        sample_path = None
        if settings.VOICE_SAMPLE_DIR:
            ext = _detect_format(audio_bytes)
            sample_path = os.path.join(
                settings.VOICE_SAMPLE_DIR,
                f"user_{user_id}_sample_{count + 1}{ext}"
            )
            Path(sample_path).parent.mkdir(parents=True, exist_ok=True)
            with open(sample_path, "wb") as f:
                f.write(audio_bytes)

        conn.execute(
            "INSERT INTO voice_embeddings (user_id, embedding, sample_path) VALUES (?, ?, ?)",
            (user_id, blob, sample_path)
        )
        conn.commit()
        print(f"[voice_auth] Saved clean embedding for user {user_id}, sample #{count + 1}, dim={len(embedding)}")
        return True, f"Voice sample {count + 1} saved successfully."

    except Exception as e:
        return False, f"Database error: {e}"
    finally:
        conn.close()


def verify_voice(
    audio_bytes: bytes,
    expected_user_id: Optional[int] = None,
    threshold_override: Optional[float] = None
) -> Tuple[bool, Optional[int], Optional[str], float]:
    """
    Compare incoming audio against stored embeddings — v8.0.

    Improvements:
    - Spectral entropy pre-check: rejects TV/music/background before embedding comparison
    - Multi-sample consistency: requires score >= threshold on average of top-2 samples
    - Adaptive threshold: scales slightly based on sample count (more samples = stricter)
    - Better rejection messages to guide user

    Returns (authenticated, user_id, user_name, best_similarity_score).
    """
    # ── v8: Quick quality + spectral entropy pre-check ──────────────────────
    ok, reason, _, _ = analyze_audio_quality(audio_bytes)
    if not ok:
        print(f"[voice_auth] verify_voice rejected by quality gate: {reason}")
        return False, None, None, 0.0

    probe = _extract_embedding(audio_bytes)
    if probe is None:
        print("[voice_auth] Could not extract probe embedding")
        return False, None, None, 0.0

    conn = get_connection()
    try:
        params: tuple = ()
        where = ""
        if expected_user_id is not None:
            where = "WHERE ve.user_id = ?"
            params = (expected_user_id,)

        rows = conn.execute(f"""
            SELECT ve.user_id, ve.embedding, u.name
            FROM voice_embeddings ve
            JOIN users u ON u.id = ve.user_id
            {where}
        """, params).fetchall()

        if not rows:
            print("[voice_auth] No voice embeddings found for expected user")
            return False, None, None, 0.0

        scores: List[float] = []
        best_score = 0.0
        best_user_id = None
        best_user_name = None

        for row in rows:
            try:
                stored = pickle.loads(row["embedding"])
                score = _cosine_similarity(probe, stored)
                scores.append(score)
                print(f"[voice_auth] User {row['user_id']} ({row['name']}): similarity={score:.4f}")
                if score > best_score:
                    best_score = score
                    best_user_id = row["user_id"]
                    best_user_name = row["name"]
            except Exception as e:
                print(f"[voice_auth] Error comparing embedding: {e}")

        # ── v13: Strict production threshold — no leniency discounts ────────
        # FIX: v8's "1 sample = -0.02 discount" was a security hole (an
        # under-enrolled account became easier to spoof). Enterprise-grade
        # auth must apply the SAME bar regardless of sample count; sample
        # count should only ever make verification *more* robust, never
        # more permissive.
        if threshold_override is not None:
            threshold = float(threshold_override)
        else:
            threshold = float(settings.LOCK_VOICE_SIMILARITY_THRESHOLD)

        absolute_floor = float(getattr(settings, "VOICE_SIMILARITY_ABSOLUTE_FLOOR", 0.80))
        threshold = max(threshold, absolute_floor)

        scores_sorted = sorted(scores, reverse=True)
        avg_top2 = float(np.mean(scores_sorted[:2])) if len(scores_sorted) >= 2 else best_score
        # Consistency floor: all top-2 scores must be close together (not just one fluke)
        consistency_floor = threshold - 0.02

        authenticated = (
            best_score >= threshold
            and best_score >= absolute_floor
            and avg_top2 >= consistency_floor
        )

        print(
            f"[voice_auth] Best={best_score:.4f}, avg_top2={avg_top2:.4f}, "
            f"threshold={threshold:.3f}, floor={consistency_floor:.3f}, auth={authenticated}"
        )

        if not authenticated and best_score > 0:
            if best_score < 0.50:
                rejection_msg = "Access Denied. Voice not recognized."
            elif best_score < threshold:
                rejection_msg = f"Voice similarity too low ({best_score:.0%}). Please speak clearly and try again."
            else:
                rejection_msg = "Access Denied. Voice not recognized."
        else:
            rejection_msg = None

        return authenticated, best_user_id, best_user_name, best_score

    except Exception as e:
        print(f"[voice_auth] Verification error: {e}")
        return False, None, None, 0.0
    finally:
        conn.close()


import re as _re_mod  # noqa: E402


def _fuzzy_wake_match(spoken: str, expected: str) -> bool:
    """Loose match between transcribed speech and the enrolled wake phrase.

    Tolerant of STT noise ("hey box", "hey vox please") but still requires the
    core wake-word tokens to be present — this is NOT the security boundary
    (speaker verification is), it simply gates which utterances are even
    considered as unlock attempts.
    """
    def _norm(s: str) -> str:
        return _re_mod.sub(r"[^a-z0-9 ]", "", (s or "").lower()).strip()

    spoken_n, expected_n = _norm(spoken), _norm(expected)
    if not spoken_n or not expected_n:
        return False
    expected_tokens = [t for t in expected_n.split() if len(t) > 1]
    if not expected_tokens:
        return expected_n in spoken_n
    hits = sum(1 for t in expected_tokens if t in spoken_n)
    return hits >= max(1, len(expected_tokens) - 1)  # allow at most one missed token


def authenticate_voice(
    audio_bytes: bytes,
    expected_user_id: int,
    transcribed_text: Optional[str] = None,
    required_wake_phrase: Optional[str] = None,
    threshold_override: Optional[float] = None,
) -> dict:
    """
    Enterprise-grade sequential voice authentication pipeline:

        Wake Phrase Detection → VAD → Noise Detection → Silence Detection →
        Speaker Embedding Extraction → Speaker Verification →
        Confidence Threshold Validation → Unlock

    Every stage can independently deny access. The function NEVER unlocks
    unless every stage passes AND the speaker embedding matches ONLY the
    enrolled `expected_user_id` above the production-grade threshold.

    Returns a dict:
        {
          "authenticated": bool,
          "stage": str,              # which stage decided the outcome
          "user_id": int|None,
          "user_name": str|None,
          "similarity_score": float,
          "message": str,            # user-facing message
        }
    """
    def deny(stage: str, message: str, score: float = 0.0) -> dict:
        print(f"[voice_auth] pipeline DENY at stage='{stage}': {message}")
        return {
            "authenticated": False,
            "stage": stage,
            "user_id": None,
            "user_name": None,
            "similarity_score": round(float(score), 4),
            "message": message,
        }

    # ── Stage 0: Wake Phrase Detection ──────────────────────────────────────
    if required_wake_phrase:
        if not transcribed_text:
            return deny("wake_phrase", "No speech detected. Please speak again.")
        if not _fuzzy_wake_match(transcribed_text, required_wake_phrase):
            return deny(
                "wake_phrase",
                "Wake phrase not recognized. Please say your wake phrase clearly to unlock.",
            )

    # ── Stage 1-3: VAD / Noise Detection / Silence Detection ───────────────
    # analyze_audio_quality runs all three checks in one pass (duration/RMS =
    # silence, VAD split = voice activity, spectral entropy + energy
    # uniformity = noise/broadcast/replay detection).
    quality_ok, quality_msg, y, sr = analyze_audio_quality(audio_bytes)
    if not quality_ok:
        if "noise" in quality_msg.lower() or "quieter" in quality_msg.lower():
            stage = "noise_detection"
        else:
            stage = "vad_silence_detection"
        return deny(stage, quality_msg)

    # ── Stage 4: Speaker Embedding Extraction ───────────────────────────────
    probe_embedding = _extract_embedding(audio_bytes)
    if probe_embedding is None:
        return deny("embedding_extraction", "No speech detected. Please speak again.")

    # ── Stage 5 & 6: Speaker Verification + Confidence Threshold Validation ─
    # Compares ONLY against the enrolled user's own stored embeddings —
    # expected_user_id is always passed, so a match against any other
    # account's voiceprint is architecturally impossible here.
    authenticated, user_id, user_name, score = verify_voice(
        audio_bytes,
        expected_user_id=expected_user_id,
        threshold_override=threshold_override,
    )

    if not authenticated:
        return deny(
            "speaker_verification",
            "Authentication failed. Only the registered user's voice can access this application.",
            score,
        )

    # ── Stage 7: Unlock ──────────────────────────────────────────────────────
    return {
        "authenticated": True,
        "stage": "unlock",
        "user_id": user_id,
        "user_name": user_name,
        "similarity_score": round(float(score), 4),
        "message": f"Welcome back, {user_name}!",
    }


def get_voice_sample_count(user_id: int) -> int:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COUNT(*) as cnt FROM voice_embeddings WHERE user_id = ?",
            (user_id,)
        ).fetchone()
        return row["cnt"]
    finally:
        conn.close()
