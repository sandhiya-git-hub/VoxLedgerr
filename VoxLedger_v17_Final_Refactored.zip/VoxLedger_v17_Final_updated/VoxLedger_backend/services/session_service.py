"""
Session service — v16

Issues a short-lived, opaque token when /verify-voice succeeds. Write
endpoints (transactions, budget, notifications) require this token via the
`X-Session-Token` header, so that voice authentication is enforced by the
API itself and not just by the frontend UI choosing when to call those
routes.

Not a full auth system (no refresh tokens, no per-device revocation list) —
appropriately scoped for a single-user local app. But it closes the gap
where any HTTP client that knew/guessed a user_id could mutate financial
data with zero proof of having passed voice authentication.
"""
import secrets
from database import get_connection

SESSION_TTL_HOURS = 12


def create_session(user_id: int) -> str:
    """Create a new session token for a user, valid for SESSION_TTL_HOURS."""
    token = secrets.token_urlsafe(32)
    conn = get_connection()
    try:
        conn.execute(
            """INSERT INTO sessions (token, user_id, created_at, expires_at)
               VALUES (?, ?, datetime('now'), datetime('now', ?))""",
            (token, user_id, f"+{SESSION_TTL_HOURS} hours"),
        )
        conn.commit()
        return token
    finally:
        conn.close()


def get_session_user_id(token: str):
    """Return the user_id for a valid, non-expired token, or None."""
    if not token:
        return None
    conn = get_connection()
    try:
        row = conn.execute(
            """SELECT user_id FROM sessions
               WHERE token = ? AND expires_at > datetime('now')""",
            (token,),
        ).fetchone()
        return row["user_id"] if row else None
    finally:
        conn.close()


def invalidate_session(token: str) -> None:
    if not token:
        return
    conn = get_connection()
    try:
        conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
        conn.commit()
    finally:
        conn.close()


def cleanup_expired_sessions() -> None:
    conn = get_connection()
    try:
        conn.execute("DELETE FROM sessions WHERE expires_at <= datetime('now')")
        conn.commit()
    finally:
        conn.close()
