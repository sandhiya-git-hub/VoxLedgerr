# VoxLedger Setup & Operations Guide

This guide covers developer installation, environment configuration, local development startup, production builds, testing, and troubleshooting.

---

## 1. System Requirements

- **Python**: 3.10, 3.11, or 3.12 (Python 3.11 recommended)
- **Node.js**: v18.0.0 or higher (v20+ / v22+ LTS verified)
- **NPM**: v9.0.0 or higher
- **FFmpeg**: Required for audio transcoding and TTS tempo scaling

### Installing FFmpeg
- **Windows** (winget or scoop):
  ```bash
  winget install Gyan.FFmpeg
  ```
  *Ensure `ffmpeg` is available on your system `PATH` by running `ffmpeg -version`.*
- **macOS** (Homebrew):
  ```bash
  brew install ffmpeg
  ```
- **Linux** (Debian/Ubuntu):
  ```bash
  sudo apt-get update && sudo apt-get install -y ffmpeg
  ```

---

## 2. Quickstart for Development

### Terminal 1: Backend Setup & Run

```bash
cd VoxLedger_backend

# 1. Create and activate Python virtual environment
python -m venv venv
# On Windows PowerShell:
.\venv\Scripts\Activate.ps1
# On Linux / macOS:
# source venv/bin/activate

# 2. Install backend dependencies
pip install -r requirements.txt

# 3. (Optional) Copy environment template
cp .env.example .env

# 4. Start FastAPI server with auto-reload
uvicorn main:app --reload --port 8000
```
- Backend runs at: `http://localhost:8000`
- Interactive OpenAPI docs: `http://localhost:8000/docs`

### Terminal 2: Frontend Setup & Run

```bash
cd VoxLedger_frontend

# 1. Install frontend dependencies
npm ci

# 2. Start Vite development server
npm run dev
```
- Frontend application runs at: `http://localhost:5173`
- The Vite dev server automatically proxies all API calls (`/health`, `/register`, `/verify-voice`, `/transactions`, etc.) to `http://localhost:8000`.

---

## 3. Production Build and Execution

VoxLedger features a compiled production Express server that serves optimized static assets and handles high-throughput reverse proxying to FastAPI.

### Building Frontend Assets and Server

```bash
cd VoxLedger_frontend

# Run full production build (builds client assets and compiles server/index.ts)
npm run build
```
Build outputs:
- Frontend static assets: `VoxLedger_frontend/dist/public/`
- Compiled Express server: `VoxLedger_frontend/dist/server/index.js`

### Running in Production

```bash
# Start backend
cd VoxLedger_backend
uvicorn main:app --host 0.0.0.0 --port 8000 &

# Start production frontend server
cd VoxLedger_frontend
npm start
```
- Production application runs at: `http://localhost:3001`
- The Express server serves `dist/public/index.html` and static files.
- All API routes are proxied to `http://localhost:8000` with byte-stream preservation.

---

## 4. Environment Variables Reference

Create a `.env` file inside `VoxLedger_backend/` (or root):

| Variable | Default | Description |
|---|---|---|
| `APP_NAME` | `"VoxLedger API"` | Application display name |
| `APP_VERSION` | `"12.0.0"` | Backend release version |
| `DEBUG` | `true` | Set to `false` in production |
| `ENVIRONMENT` | `"development"` | Set to `"production"` in production environments |
| `SECRET_KEY` | *(insecure default)* | Must be set to a secure string in production |
| `ALGORITHM` | `"HS256"` | JWT/Token signing algorithm |
| `LOCK_VOICE_SIMILARITY_THRESHOLD` | `0.55` | Primary cosine similarity threshold for unlock |
| `VOICE_SIMILARITY_ABSOLUTE_FLOOR` | `0.50` | Hard floor below which authentication is denied |
| `WHISPER_MODEL` | `"small"` | Whisper model size (`tiny`, `base`, `small`, `medium`) |
| `TTS_SPEED` | `1.35` | Playback speed multiplier applied via FFmpeg |
| `ANTHROPIC_API_KEY` | *(optional)* | Claude AI key for natural language intent fallback |

---

## 5. Maintenance Scripts

All maintenance utilities reside in `VoxLedger_backend/scripts/`:

### 1. Recalibrate Speaker Verification Thresholds
Derives genuine vs. impostor similarity distributions from stored audio samples:
```bash
cd VoxLedger_backend
python scripts/calibrate_threshold.py
```

### 2. Re-embed Stored Voice Profiles
Re-computes 165-dimensional block-normalized feature embeddings from raw voice samples:
```bash
cd VoxLedger_backend
python scripts/reembed_voice_profiles.py
```

### 3. Clear User Data
Resets the SQLite database tables for a fresh onboarding state:
```bash
cd VoxLedger_backend
python scripts/reset_db.py
```

---

## 6. Testing

### Run Backend Tests
```bash
cd VoxLedger_backend
pytest tests/test_full_suite.py -v
```

### Run Frontend Tests and Typecheck
```bash
cd VoxLedger_frontend
npm run typecheck
npm run test
```

---

## 7. Troubleshooting

- **`Backend unreachable (502 Bad Gateway)`**: Ensure FastAPI is running on port 8000 (`uvicorn main:app --port 8000`).
- **`Audio conversion failed`**: Verify `ffmpeg` is installed and in your system PATH (`ffmpeg -version`).
- **`Silence detected`**: Check your microphone permissions in the browser and ensure input volume is adequate.
