# VoxLedger — Voice-First AI Personal Finance Assistant

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110%2B-009688.svg)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/React-18-61DAFB.svg)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.2-3178C6.svg)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-5.0-646CFF.svg)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-3.3-38B2AC.svg)](https://tailwindcss.com/)

**VoxLedger** is a voice-first personal finance assistant engineered for hands-free financial tracking, budgeting, and biometric speaker verification. It couples a responsive **React 18 + TypeScript** client with a high-throughput **Python FastAPI** backend powered by local **OpenAI Whisper speech recognition**, custom **MFCC voice biometrics**, and accelerated **gTTS speech synthesis**.

---

## Key Highlights

- 🎙️ **Voice Biometric Authentication**: Multi-sample MFCC feature extraction (165 dimensions) with block L2-normalization, strict VAD quality gating, and silence rejection.
- 🗣️ **Local Speech-to-Text**: Whisper STT with greedy decoding and dedicated post-processing for Indian English financial terminology.
- ⚡ **Instant TTS Interruption**: Natural speech playback accelerated using FFmpeg tempo scaling, interruptible immediately on user command ("Stop").
- 🔒 **Session-Gated Ledger**: Cryptographic session tokens (`X-Session-Token`) issued upon biometric unlock; direct unauthorized API requests to financial data are blocked.
- 🚀 **Dual-Mode Build Architecture**: Fully configured development proxy (Vite) and compiled production server (Express + esbuild) sharing a single source of truth for API route forwarding.
- 📊 **Proactive Alerts & Budget Engine**: Automated budget utilization warnings (80% warning, 95% critical) without hardcoded default ceilings.

---

## System Architecture

```
┌────────────────────────────────────────────────────────┐
│               React + TypeScript Frontend             │
│        (Persistent Layout & Ambient Audio Engine)      │
└───────────────────────────┬────────────────────────────┘
                            │
               HTTP Requests & Audio Streams
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│         Reverse Proxy Gateway (Vite / Express)         │
│         - Shared Route Configuration (api-routes)      │
│         - Unbuffered Raw Byte Stream Forwarding        │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│               Python FastAPI Backend                   │
│   ┌────────────────────┐    ┌──────────────────────┐   │
│   │ Voice Biometrics   │    │ Whisper STT & Intent │   │
│   │ (MFCC + VAD Gate)  │    │ (Fast Keyword/Claude)│   │
│   └────────────────────┘    └──────────────────────┘   │
│   ┌────────────────────┐    ┌──────────────────────┐   │
│   │ Accounting Ledger  │    │ Session Auth Guard   │   │
│   │ (SQLite WAL Mode)  │    │ (X-Session-Token)    │   │
│   └────────────────────┘    └──────────────────────┘   │
└────────────────────────────────────────────────────────┘
```

For complete architectural details, consult [ARCHITECTURE.md](ARCHITECTURE.md).

---

## Repository Structure

```
VoxLedger_v17_Final_updated/
├── README.md                     # Root project documentation (this file)
├── ARCHITECTURE.md               # Detailed system architecture and design
├── API_DOCUMENTATION.md          # REST API reference and contracts
├── SETUP_GUIDE.md                # Detailed setup and troubleshooting guide
├── .env.example                  # Root environment variables template
├── .gitignore                    # Comprehensive repository gitignore
│
├── VoxLedger_frontend/           # React + TypeScript Frontend
│   ├── client/                   # Frontend source code
│   │   ├── main.tsx              # DOM root mount entrypoint
│   │   ├── App.tsx               # Primary router & providers
│   │   ├── assets/               # Static assets and icons
│   │   ├── styles/               # Stylesheets (global.css)
│   │   ├── components/           # UI components & persistent Layout
│   │   │   ├── Layout.tsx        # Persistent voice assistant audio engine
│   │   │   ├── SplashScreen.tsx  # Initial app launch router
│   │   │   └── ui/               # Active Radix UI primitives
│   │   ├── context/              # AppContext state hub
│   │   ├── hooks/                # Custom React hooks (useToast)
│   │   ├── lib/                  # Type-safe API client & utilities
│   │   └── pages/                # Application views (Index, Transactions, Budget, etc.)
│   ├── server/                   # Production Express server (index.ts)
│   ├── shared/                   # Shared API route definitions (api-routes.ts)
│   ├── index.html                # Application entry HTML
│   ├── package.json              # NPM scripts and dependencies
│   └── vite.config.ts            # Vite build & proxy configuration
│
└── VoxLedger_backend/            # Python FastAPI Backend
    ├── main.py                   # FastAPI entrypoint & router assembly
    ├── config.py                 # Application settings & security validator
    ├── database.py               # SQLite connection manager & migrations
    ├── requirements.txt          # Python dependencies
    ├── database/                 # SQLite storage (voxledger.db, voice_samples/, tts_cache/)
    ├── models/                   # Pydantic schemas (user, transaction, budget, notification)
    ├── routes/                   # API route handlers (auth, transaction, budget, voice)
    ├── services/                 # Voice auth, Whisper STT, TTS, finance logic, sessions
    ├── utils/                    # Intent parsing, date extraction, session auth guard
    ├── scripts/                  # Maintenance scripts (calibrate, reembed, reset)
    └── tests/                    # Automated regression test suite
```

---

## Quickstart

### Prerequisites
- **Python 3.10+** (Python 3.11 recommended)
- **Node.js 18+**
- **FFmpeg** (installed and added to system `PATH`)

### 1. Start Backend (Terminal 1)

```bash
cd VoxLedger_backend

# Create virtual environment
python -m venv venv
# Windows:
.\venv\Scripts\Activate.ps1
# Linux/macOS:
# source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Start backend server
uvicorn main:app --reload --port 8000
```
- API Endpoint: `http://localhost:8000`
- Interactive API Docs: `http://localhost:8000/docs`

### 2. Start Frontend (Terminal 2)

```bash
cd VoxLedger_frontend

# Install dependencies cleanly
npm ci

# Start development server
npm run dev
```
- Frontend Web App: `http://localhost:5173`

---

## Production Build & Execution

The production build compiles both client web assets and the Node.js Express server:

```bash
cd VoxLedger_frontend

# Build frontend assets (dist/public) & compile server (dist/server/index.js)
npm run build

# Start production server
npm start
```
- Application serves from: `http://localhost:3001`
- Static files served from `dist/public/`
- API calls reverse-proxied to FastAPI at `http://localhost:8000`

---

## Voice Commands Guide

| Category | Example Utterance | Resulting Action |
|---|---|---|
| **Expense** | *"Add 450 for groceries"* | Adds ₹450 expense under Food category |
| **Income** | *"I received 50000 salary"* | Records ₹50,000 income |
| **Balance** | *"What's my balance?"* | Calculates and speaks net balance |
| **Budget** | *"Set monthly budget to 30000"* | Updates monthly budget ceiling |
| **Budget Query**| *"What is my remaining budget?"* | Calculates remaining budget and utilization % |
| **Navigation** | *"Go to transactions"*, *"Open budget"* | Hands-free page navigation |
| **Control** | *"Stop"* | Immediately interrupts speech playback |
| **Undo** | *"Undo that"*, *"Delete last transaction"* | Prompts confirmation and removes record |

---

## Testing & Quality Assurance

### Run Frontend Tests & Typecheck
```bash
cd VoxLedger_frontend
npm run typecheck
npm run test
```

### Run Backend Regression Test Suite
```bash
cd VoxLedger_backend
pytest tests/test_full_suite.py -v
```

---

## Documentation Links

- [System Architecture Document](ARCHITECTURE.md)
- [REST API Specifications](API_DOCUMENTATION.md)
- [Developer & Production Setup Guide](SETUP_GUIDE.md)
- [Frontend README](VoxLedger_frontend/README.md)
- [Backend README](VoxLedger_backend/README.md)
