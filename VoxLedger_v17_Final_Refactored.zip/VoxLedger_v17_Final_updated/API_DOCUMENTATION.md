# VoxLedger REST API Documentation

This document describes all HTTP REST endpoints exposed by the VoxLedger FastAPI backend (default port `8000`), proxyable via the frontend development server (`http://localhost:5173`) and Express production server (`http://localhost:3001`).

---

## 1. Authentication & Session Management

All write and finance endpoints require a valid session token in the HTTP header:
```http
X-Session-Token: <token>
```
Session tokens are issued upon successful voice unlock (`/verify-voice`) and validated against the `sessions` table in SQLite.

---

### Check User Registration Status
Inspects whether any user account is enrolled and whether biometric profiles exist.

- **URL**: `GET /check-user`
- **Headers**: None
- **Response**: `200 OK`
```json
{
  "registered": true,
  "user_id": 1,
  "user_name": "Alex Mercer",
  "has_user": true,
  "has_voice_profile": true
}
```

---

### Register User
Creates a new primary user record.

- **URL**: `POST /register`
- **Content-Type**: `multipart/form-data` or `application/x-www-form-urlencoded`
- **Fields**:
  - `name`: String (2-100 characters)
  - `password`: String (min 4 characters)
- **Response**: `200 OK`
```json
{
  "success": true,
  "message": "User registered successfully.",
  "user_id": 1,
  "user_name": "Alex Mercer"
}
```
- **Errors**: `409 Conflict` if username already registered.

---

### Upload Voice Biometric Sample
Uploads an audio recording to extract and store speaker embeddings.

- **URL**: `POST /register/voice-sample`
- **Content-Type**: `multipart/form-data`
- **Fields**:
  - `user_id`: Integer
  - `voice_sample`: Audio file binary (WAV, WebM, MP3)
- **Response**: `200 OK`
```json
{
  "success": true,
  "message": "Voice sample 1 of 10 registered successfully.",
  "samples_registered": 1,
  "max_samples": 10,
  "registration_complete": true
}
```

---

### Verify Voice (Biometric Unlock)
Verifies input voice against stored embeddings and wake phrase. Issues session token on success.

- **URL**: `POST /verify-voice`
- **Content-Type**: `multipart/form-data`
- **Fields**:
  - `voice_sample`: Audio file binary
  - `wake_phrase`: String (optional override)
- **Response**: `200 OK`
```json
{
  "authenticated": true,
  "user_id": 1,
  "user_name": "Alex Mercer",
  "similarity_score": 0.634,
  "message": "Voice verified. Welcome back, Alex Mercer!",
  "stage": "complete",
  "session_token": "a1b2c3d4e5f6..."
}
```
- **Rejection Responses**:
  - Silence detected: `authenticated: false`, message indicates low audio energy.
  - Low similarity: `authenticated: false`, score below `LOCK_VOICE_SIMILARITY_THRESHOLD`.

---

### Set Wake Phrase
Configures the custom or default wake phrase for a user.

- **URL**: `POST /set-wake-phrase`
- **Content-Type**: `multipart/form-data`
- **Fields**:
  - `user_id`: Integer
  - `wake_phrase`: String (e.g. `"hey vox"`, `"namaste vox"`)
- **Response**: `200 OK`
```json
{
  "success": true,
  "wake_phrase": "hey vox"
}
```

---

### Logout
Invalidates the caller's active session token.

- **URL**: `POST /logout`
- **Headers**: `X-Session-Token: <token>`
- **Response**: `200 OK`
```json
{
  "success": true,
  "message": "Logged out successfully."
}
```

---

## 2. Transactions API

*All transaction endpoints require `X-Session-Token` header.*

### Add Expense
Records an outflow transaction.

- **URL**: `POST /transactions/add-expense`
- **Content-Type**: `application/json`
- **Body**:
```json
{
  "user_id": 1,
  "amount": 450.0,
  "category": "Food",
  "description": "Lunch at cafe",
  "title": "Lunch",
  "tx_date": "2026-11-12"
}
```
- **Response**: `200 OK`
```json
{
  "success": true,
  "message": "₹450 added to Food.",
  "transaction": {
    "id": 1,
    "user_id": 1,
    "title": "Lunch",
    "amount": -450.0,
    "category": "Food",
    "description": "Lunch at cafe",
    "tx_date": "2026-11-12",
    "created_at": "2026-11-12 19:30:00"
  },
  "updated_balance": 14550.0,
  "summary": { ... }
}
```

---

### Add Income
Records an inflow transaction.

- **URL**: `POST /transactions/add-income`
- **Content-Type**: `application/json`
- **Body**:
```json
{
  "user_id": 1,
  "amount": 25000.0,
  "category": "Salary",
  "description": "November paycheck",
  "title": "Salary"
}
```
- **Response**: `200 OK`

---

### List Transactions
Fetches filtered transactions for the user.

- **URL**: `GET /transactions`
- **Query Parameters**:
  - `user_id`: Integer (required)
  - `period`: String (`today`, `week`, `month`, `year`, `all`)
  - `category`: String (optional)
  - `search`: String (optional)
  - `limit`: Integer (default 100, max 500)
- **Response**: `200 OK`
```json
{
  "transactions": [ ... ],
  "count": 12,
  "period": "month"
}
```

---

### Financial Summary
Retrieves income, expense, balance, and budget metrics.

- **URL**: `GET /transactions/summary`
- **Query Parameters**:
  - `user_id`: Integer
  - `period`: String (`today`, `week`, `month`, `year`)
- **Response**: `200 OK`
```json
{
  "total_income": 50000.0,
  "total_expenses": 12450.0,
  "net_balance": 37550.0,
  "monthly_budget": 30000.0,
  "budget_used_pct": 0.415,
  "remaining_budget": 17550.0,
  "transaction_count": 28,
  "top_category": "Food"
}
```

---

### Delete Transaction
Deletes a transaction by ID.

- **URL**: `DELETE /transactions/{tx_id}?user_id={user_id}`
- **Response**: `200 OK`
```json
{
  "success": true,
  "message": "Transaction deleted."
}
```

---

## 3. Budget API

*All budget endpoints require `X-Session-Token` header.*

### Set Budget
Sets or updates a monthly or category budget.

- **URL**: `POST /budget/set`
- **Content-Type**: `application/json`
- **Body**:
```json
{
  "user_id": 1,
  "category": "monthly",
  "amount": 30000.0,
  "month": "2026-11"
}
```
- **Response**: `200 OK`

---

### Get Budget Summary
Retrieves monthly and category budgets with real-time spending progress.

- **URL**: `GET /budget`
- **Query Parameters**:
  - `user_id`: Integer
  - `month`: String (`YYYY-MM`, optional; defaults to current month)
- **Response**: `200 OK`
```json
{
  "month": "2026-11",
  "monthly_budget": 30000.0,
  "total_spent": 12450.0,
  "remaining": 17550.0,
  "used_pct": 0.415,
  "categories": [
    {
      "id": 1,
      "user_id": 1,
      "category": "Food",
      "amount": 8000.0,
      "month": "2026-11",
      "spent": 4200.0,
      "remaining": 3800.0,
      "used_pct": 0.525
    }
  ]
}
```

---

## 4. Voice & Speech Processing API

### Process Voice Command
Accepts an audio stream, transcribes with Whisper, parses intent, executes finance action, and generates TTS URL.

- **URL**: `POST /voice/voice-command`
- **Content-Type**: `multipart/form-data`
- **Fields**:
  - `user_id`: Integer
  - `audio`: Audio file binary (WAV, WebM)
  - `language`: String (`"en"`)
  - `tts`: Boolean (`true`)
  - `require_wake_phrase`: Boolean
- **Response**: `200 OK`
```json
{
  "success": true,
  "transcribed_text": "Spent 250 on coffee",
  "intent": "add_expense",
  "response_text": "₹250 added to Food. Your remaining balance is ₹14,750.",
  "tts_audio_url": "/voice/tts?text=...",
  "action_result": {
    "transaction": { ... },
    "summary": { ... }
  }
}
```

---

### Process Text Command
Executes a natural language text command directly (keyboard fallback or testing).

- **URL**: `POST /voice/text-command`
- **Content-Type**: `multipart/form-data`
- **Fields**:
  - `user_id`: Integer
  - `text`: String (`"What is my remaining budget?"`)
- **Response**: Same schema as `/voice/voice-command`.

---

### Text-to-Speech Streaming (TTS)
Streams synthesized audio for spoken responses.

- **URL**: `GET /voice/tts?text={encoded_text}`
- **Response**: `200 OK`, `Content-Type: audio/mpeg`
- **Features**: Cached on disk, accelerated with ffmpeg tempo scaling.

---

### Conversation History
Fetches recent conversational turns between user and assistant.

- **URL**: `GET /voice/conversation-history?user_id={user_id}&limit=50`
- **Response**: `200 OK`
```json
{
  "conversation": [
    {
      "id": 1,
      "role": "user",
      "content": "Add 500 for groceries",
      "created_at": "2026-11-12 18:20:15"
    },
    {
      "id": 2,
      "role": "assistant",
      "content": "₹500 added to Food.",
      "created_at": "2026-11-12 18:20:16"
    }
  ],
  "count": 2
}
```

---

## 5. Health & Diagnostic Endpoints

### Root Service Info
- **URL**: `GET /`
- **Response**: `{"app": "VoxLedger API", "version": "12.0.0", "status": "running", "docs": "/docs"}`

### Health Probe
- **URL**: `GET /health`
- **Response**: `{"status": "ok"}`
